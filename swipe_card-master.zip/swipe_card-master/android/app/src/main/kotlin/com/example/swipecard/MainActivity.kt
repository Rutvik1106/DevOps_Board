package com.example.swipecard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
