# swipecard

Swipe card example

https://www.youtube.com/watch?v=2yEb9YOwZr8
